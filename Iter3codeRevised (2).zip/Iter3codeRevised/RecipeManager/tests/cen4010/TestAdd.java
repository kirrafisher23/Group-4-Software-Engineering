package cen4010;

import static org.junit.jupiter.api.Assertions.*;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.junit.After;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestAdd {

	private Connection conn;
    private RecipeDatabase recipeDatabase;

    @BeforeEach
    public void setUp() throws SQLException {
    	String user = "G25";
    	String pass = "Password";
    	String connection = "jdbc:oracle:thin:@cisvm-oracle.unfcsd.unf.edu:1521:orcl";
        conn = DriverManager.getConnection(connection, user, pass);
    	this.recipeDatabase =  new RecipeDatabase();
    }

    @After
    public void tearDown() throws SQLException {
        conn.close();
    }

    /**
     * test AddRecipe method by adding a test recipe and checking if the database contains the recipe
     */
    @Test
    public void testAddRecipe() {
        //Test recipe info
        String recipeName = "Test Recipe";
        String recipeTime = "30 min";
        int servingSize = 4;
        String ingredients = "Ingredient 1, Ingredient 2";
        String tags = "Tag 1, Tag 2";
        String steps = "Step 1, Step 2";

        //Add test recipe to the database
        recipeDatabase.addRecipe(recipeName, recipeTime, servingSize, ingredients, tags, steps);

        //Check if the test recipe is in the database
        try (Statement stmt = conn.createStatement()) {
            String query = "SELECT * FROM recipe WHERE recipe_name = '" + recipeName + "'";
            try (ResultSet resultSet = stmt.executeQuery(query)) {
                if (resultSet.next()) {
                    assertEquals(recipeTime, resultSet.getString("recipe_time"));
                    assertEquals(servingSize, resultSet.getInt("recipe_serving_size"));
                } else {
                    fail("Recipe not found in the database.");
                }
            }
        } catch (SQLException e) {
            fail("Error: " + e.getMessage());
        }
    }
    

}
