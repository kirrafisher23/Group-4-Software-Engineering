package cen4010;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.junit.After;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.sql.ResultSet;
import java.sql.Statement;

class TestEdit {
	
	private Connection conn;
    private RecipeDatabase recipeDatabase;

    @BeforeEach
    public void setUp() throws SQLException {
    	String user = "G25";
    	String pass = "Password";
    	String connection = "jdbc:oracle:thin:@cisvm-oracle.unfcsd.unf.edu:1521:orcl";
        conn = DriverManager.getConnection(connection, user, pass);
    	this.recipeDatabase =  new RecipeDatabase();
    }

    @After
    public void tearDown() throws SQLException {
        conn.close();
    }

    /**
     * edits an existing recipe in the database then deletes it
     */
	@Test
    public void testEditRecipe() {
        //Create a test recipe
        String recipeName = "Test Recipe";
        String updatedRecipeName = "Updated Recipe";
        String recipeTime = "30 min";
        String servingSize = "4";
        String ingredients = "Ingredient 1, Ingredient 2";
        String tags = "Tag 1, Tag 2";
        String steps = "Step 1, Step 2";

        recipeDatabase.saveEditedRecipe(recipeName, updatedRecipeName, recipeTime, servingSize, ingredients, tags, steps);

        try (Statement stmt = conn.createStatement()) {
            String query = "SELECT * FROM recipe WHERE recipe_name = '" + updatedRecipeName + "'";
            try (ResultSet resultSet = stmt.executeQuery(query)) {
                if (resultSet.next()) {
                    assertEquals(recipeTime, resultSet.getString("recipe_time"));
                    assertEquals(servingSize, resultSet.getString("recipe_serving_size"));
                } else {
                    fail("Edited recipe not found in the database.");
                }
            }
        } catch (SQLException e) {
            fail("Error: " + e.getMessage());
        }
        
        
        /*delete the updated test recipe so when the JUnit tests are run again there are no
         * errors if you don't go back and manually delete the updated test recipe before running the 
         * JUnit again.
         */
        recipeDatabase.deleteRecipe(updatedRecipeName);
    }

}
