package cen4010;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestSearch {

	//Set up database connection
    private Connection conn;
    private static RecipeDatabase recipeDatabase;
    private static RecipeManagerGUI gui;
    
    @BeforeEach
    public void setUp() throws SQLException {
        String user = "G25";
        String pass = "Password";
        String connection = "jdbc:oracle:thin:@cisvm-oracle.unfcsd.unf.edu:1521:orcl";
        conn = DriverManager.getConnection(connection, user, pass);
        this.recipeDatabase = new RecipeDatabase();
        this.gui = new RecipeManagerGUI();
    }

    @AfterEach
    public void tearDown() throws SQLException {
        conn.close();
    }
    /**
     * Tests the search method by checking searching for an existing tag
     */
    @Test
    public void testSearchByTag() {
        gui.DisplaySearchRecipeForm();
        try {
            ResultSet resultSet = recipeDatabase.performDatabaseSearch("Tag", "chicken");
            assertTrue(resultSet.next(), "Expected search result for tag 'chicken'");
        } catch (SQLException e) {
            fail("Exception occurred during search: " + e.getMessage());
        }
    }

    /**
     * tests the search method by checking for an existing recipe name
     */
    @Test
    public void testSearchByRecipeName() {
        gui.DisplaySearchRecipeForm();
        try {
            ResultSet resultSet = recipeDatabase.performDatabaseSearch("Recipe Name", "chicken");
            assertTrue(resultSet.next(), "Expected search result for recipe name 'chicken'");
        } catch (SQLException e) {
            fail("Exception occurred during search: " + e.getMessage());
        }
    }

    /**
     * tests for when the search term is left empty
     */
    @Test
    public void testEmptySearchTerm() {
        gui.DisplaySearchRecipeForm();
        try {
            ResultSet resultSet = recipeDatabase.performDatabaseSearch("Tag", " ");
            assertFalse(resultSet.next()); 
        } catch (SQLException e) {
            fail("Exception occurred during search: " + e.getMessage());
        }
    }
}
