package cen4010;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.After;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestDelete {

	private Connection conn;
    private RecipeDatabase recipeDatabase;

    @BeforeEach
    public void setUp() throws SQLException {
    	String user = "G25";
    	String pass = "Password";
    	String connection = "jdbc:oracle:thin:@cisvm-oracle.unfcsd.unf.edu:1521:orcl";
        conn = DriverManager.getConnection(connection, user, pass);
    	this.recipeDatabase =  new RecipeDatabase();
    }

    @After
    public void tearDown() throws SQLException {
        conn.close();
    }
    /**
     * first adds a test recipe to the database then deletes it
     * if it was successfully deleted then the test passes
     */
	 @Test
	    public void testDeleteRecipe() {
	        String recipeName = "Test Recipe";
	        String recipeTime = "30 min";
	        int servingSize = 4;
	        String ingredients = "Ingredient 1, Ingredient 2";
	        String tags = "Tag 3, Tag 4";
	        String steps = "Step 1, Step 2";

	        recipeDatabase.addRecipe(recipeName, recipeTime, servingSize, ingredients, tags, steps);

	        recipeDatabase.deleteRecipe(recipeName);

	        try (Statement stmt = conn.createStatement()) {
	            String query = "SELECT * FROM recipe WHERE recipe_name = '" + recipeName + "'";
	            try (ResultSet resultSet = stmt.executeQuery(query)) {
	                assertFalse(resultSet.next(), "Recipe was not deleted from the database.");
	            }
	        } catch (SQLException e) {
	            fail("Error: " + e.getMessage());
	        }
	    }

}
