using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AddIngredient : MonoBehaviour
{
    [SerializeField]
    Transform scrollPanel;
    [SerializeField]
    GameObject ingredientObject;
    public TMP_InputField ingredientInput;
    public TMP_InputField amountInput;
    public TMP_Text ingredientObjectTextField;
    [SerializeField]
    TMP_Dropdown measurementDropDown;


    public void addIngredientObject()
    {
        string combinedInput;

        string ingredient = ingredientInput.text;
        string amount = amountInput.text;

        int measurementIndex = measurementDropDown.value;
        string measurement = measurementDropDown.options[measurementIndex].text;

        if (string.Equals(measurement, "Blank"))
        {
            combinedInput = amount + " " + ingredient;
        }
        else
        {
            combinedInput = amount + " " + measurement + " " + ingredient;
        }

        ingredientObjectTextField.text = combinedInput;
        ingredientInput.text = "";
        amountInput.text = "";

        var item = Instantiate(ingredientObject);
        item.transform.SetParent(scrollPanel);
        item.transform.localScale = Vector3.one;
    }
}
