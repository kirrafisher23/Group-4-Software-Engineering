using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AddRecipeSQL : MonoBehaviour
{
    //inputted values:  recipeName, recipeTime, serveSize, ingredientName, tagCall, String steps
    //need to put delimiters ',' when addded
    //UPDATE: recipe time and serve size

    [SerializeField]
    GameObject ingredientPanel;
    [SerializeField]
    GameObject tagPanel;
    [SerializeField]
    GameObject stepPanel;
    [SerializeField]
    TMP_InputField nameField;
    [SerializeField]
    TMP_InputField servingField;
    [SerializeField]
    TMP_Dropdown timeTypeDropDown;
    [SerializeField]
    TMP_InputField cookTimeInput;

    public void addRecipe()
    {
        //take this info and insert into SQL
        string combinedIngredients = getObjectWithTag("ingredient");
        string combinedSteps = getObjectWithTag("step");
        string combinedTags = getObjectWithTag("tag");
        string name = getStringOf("name");
        string servingSize = servingField.text;
        string recipeTime = addCookTimeObject();

        addRecipeToSQL(combinedIngredients, combinedTags, combinedSteps);
        Debug.Log("Ingredients: " + combinedIngredients);
        Debug.Log("Steps: " + combinedSteps);
        Debug.Log("Tags: " + combinedTags);
        Debug.Log("Name: " + name);
        Debug.Log("Serving Size: " + servingSize);
        Debug.Log("Cook Time: " + recipeTime);
    }

    public void addRecipeToSQL(string combinedIngredients, string combinedTags, string combinedSteps)
    {
        //Recipe to SQL
    }

    public string getStringOf(string setTag)
    {
        return "";
    }

    public string getObjectWithTag(string setTag)
    {
        string combinedString = "";

        GameObject[] allParts = GameObject.FindGameObjectsWithTag(setTag);
        for(int i = 1; i < allParts.Length; i++)
        {
            GameObject part = allParts[i];
            GameObject TMPObject = part.transform.GetChild(0).gameObject;
            string objectText = getText(TMPObject);
            combinedString = combineRecipeSection(combinedString, objectText);
        }
        return combinedString;
    }

    public string getText(GameObject TMPObject)
    {
        string objectText = TMPObject.transform.GetComponent<TMP_Text>().text;
        return objectText;
    }

    public string combineRecipeSection(string combinedString, string objectText)
    {
        if(string.Equals(combinedString, ""))
        {
            combinedString = objectText;
        }
        else
        {
            combinedString = combinedString + ", " + objectText;
        }
         
        return combinedString;
    }
    public string addCookTimeObject()
    {
        string combinedCookTime;
        int timeTypeIndex = timeTypeDropDown.value;
        string timeType = timeTypeDropDown.options[timeTypeIndex].text;
        string cookTime = cookTimeInput.text;

        if(string.Equals(timeType, "Blank"))
        {
            combinedCookTime = cookTime;
        }
        else
        {
            combinedCookTime = cookTime + " " + timeType;
        }
        return combinedCookTime;
    }
}
