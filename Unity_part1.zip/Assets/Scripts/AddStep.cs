using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AddStep : MonoBehaviour
{
    [SerializeField]
    Transform scrollPanel;
    [SerializeField]
    GameObject stepObject;
    public TMP_InputField input;
    public TMP_Text stepTextField;


    public void addStepObject()
    {
        stepTextField.text = input.text;
        input.text = "";

        var item = Instantiate(stepObject);
        item.transform.SetParent(scrollPanel);
        item.transform.localScale = Vector3.one;
    }
}
