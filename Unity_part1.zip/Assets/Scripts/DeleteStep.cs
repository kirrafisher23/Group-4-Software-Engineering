using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeleteStep : MonoBehaviour
{
    [SerializeField]
    GameObject stepObject;

    public void destroyStepObject()
    {
        Destroy(stepObject);
    }
}
