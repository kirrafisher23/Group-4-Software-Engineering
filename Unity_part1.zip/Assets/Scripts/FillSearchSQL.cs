using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class FillSearchSQL : MonoBehaviour
{
    [SerializeField]
    Transform scrollPanel;
    [SerializeField]
    GameObject cardObject;
    [SerializeField]
    TMP_Text cardTextField;
    public void Start()
    {
        for(int i = 0; i < getRecipeCountSQL(); i++)
        {
            //get a name from SQL
            cardTextField.text = "Name" + i;
            var item1 = Instantiate(cardObject);
            item1.transform.SetParent(scrollPanel);
            item1.transform.localScale = Vector3.one;
        }
    }
    public string getRecipeNamesFromSQL()
    {
        return "name";
    }
    public int getRecipeCountSQL()
    {
        return 4;
    }
    
}
