using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseOverCard : MonoBehaviour
{
    public GameObject card;
    public int height;
    Vector3 originalPosition;
    float newYPosition;

    private void Start()
    {
        originalPosition = card.transform.position;
        Debug.Log(card.transform.position.x);
        newYPosition = card.transform.position.y + height;

    }

    void OnMouseOver()
    {
        card.transform.position = new Vector3(card.transform.position.x, newYPosition + height, card.transform.position.z);
        Debug.Log("MOUSE");
    }

    void OnMouseExit()
    {
        card.transform.position = originalPosition;
        Debug.Log("NO MOUSE");
    }
}
