using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PopUpManager : MonoBehaviour
{
    public GameObject popUpBox;
/*    public GameObject cancelButton;
    public GameObject saveButton;*/
    public Animator animator;

    public void popUp(string text)
    {
        popUpBox.SetActive(true);
/*        popUpText.text = text;*/
        animator.SetTrigger("pop");
    }
}
